package edu.greenriver.sdev.dictionaryapistarter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DictionaryApiStarterApplicationTests
{

    @Test
    void contextLoads()
    {
    }

}
