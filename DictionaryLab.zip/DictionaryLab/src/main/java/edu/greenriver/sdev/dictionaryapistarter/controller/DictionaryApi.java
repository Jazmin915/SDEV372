package edu.greenriver.sdev.dictionaryapistarter.controller;

import edu.greenriver.sdev.dictionaryapistarter.dtos.WordDefinition;
import edu.greenriver.sdev.dictionaryapistarter.services.DictionaryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class DictionaryApi {
    private DictionaryService dictionary;

    public DictionaryApi(DictionaryService dictionary) {
        this.dictionary = dictionary;
    }

    // Read all the words
    @GetMapping("api/v1/dict")
    public ResponseEntity<List<String>> getAllWords() {
        return new ResponseEntity<>(dictionary.allWords(), HttpStatus.OK);
    }

    // Get definition of a specific word using a path variable
    @GetMapping("api/v1/dict/{word}")
    public ResponseEntity<String> getDefinition(@PathVariable String word) {
        String definition = dictionary.getDefinition(word).orElse(null);

        if (definition != null) {
            // Word found, return 200 OK
            return new ResponseEntity<>(definition, HttpStatus.OK);
        } else {
            // Word not found, return 404 Not Found
            return new ResponseEntity<>("Word not found", HttpStatus.NOT_FOUND);
        }
    }

    // (POST) Add new word/definition
    @PostMapping("api/v1/dict/{word}/{definition}")
    public ResponseEntity<WordDefinition> addWordDefinition(
            @PathVariable String word,
            @PathVariable String definition) {
        if (dictionary.getDefinition(word).isPresent()) {
            // Word already in the dictionary, return 400 Bad Request
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        WordDefinition added = dictionary.addWord(word, definition);

        //qord successfully added, return 201 Created
        return new ResponseEntity<>(added, HttpStatus.CREATED);
    }

    //POST adds a new word and definition using parameters
    @PostMapping("api/v1/dict/param")
    public ResponseEntity<WordDefinition> addWordFromParam(
            @RequestParam String word,
            @RequestParam String definition) {
        if (dictionary.getDefinition(word).isPresent()) {
            //word already in the dictionary so return 400 Bad Request
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        WordDefinition added = dictionary.addWord(word, definition);

        // return 201 Created
        return new ResponseEntity<>(added, HttpStatus.CREATED);
    }

    // (POST) Add a new word and def using the request body
    @PostMapping("api/v1/dict/body")
    public ResponseEntity<WordDefinition> addWordWithRequest(@RequestBody WordDefinition wordDefinition) {
        String word = wordDefinition.getWord();
        String definition = wordDefinition.getDefinition();

        if (dictionary.getDefinition(word).isPresent()) {
            // return 400 Bad Request
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        WordDefinition added = dictionary.addWord(word, definition);

        //return 201 Created
        return new ResponseEntity<>(added, HttpStatus.CREATED);
    }
}