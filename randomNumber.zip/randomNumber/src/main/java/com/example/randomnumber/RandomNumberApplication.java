package com.example.randomnumber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RandomNumberApplication {

    public static void main(String[] args) {
        SpringApplication.run(RandomNumberApplication.class, args);
    }

}
