package com.example.randomnumber.controllers;

import com.example.randomnumber.services.NumberService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

@Controller
public class NumberController {

    private NumberService service;

    public NumberController(NumberService service)
    {
        this.service = service;
    }

    /*@RequestMapping goes here*/
    @RequestMapping("randnum")
    public String genNumber(Model modelVars)
    {
        //System.out.println("genNumber method called");
        modelVars.addAttribute("num", service.between(1, 20));
        return "randnum";
    }


    @RequestMapping("powerball")
    public String genNumberPowerball(Model modelVars)
    {
        //System.out.println("genNumber method called");
        modelVars.addAttribute("num", service.between(1, 70));
        modelVars.addAttribute("num1", service.between(1, 70));
        modelVars.addAttribute("num2", service.between(1, 70));
        modelVars.addAttribute("num3", service.between(1, 70));
        modelVars.addAttribute("num4", service.between(1, 70));
        modelVars.addAttribute("num5", service.between(1, 30));

        return "powerball";
    }

    @RequestMapping("randgroup")
    public String genNumberChallenge(Model modelVars)
    {
        ArrayList<Integer> randNumbers = new ArrayList<>();
        for (int i = 0; i < 20; i++)
        {
            randNumbers.add(service.between(0,21));

        }
        modelVars.addAttribute("nums", randNumbers);

        return "randgroup";
    }

}
