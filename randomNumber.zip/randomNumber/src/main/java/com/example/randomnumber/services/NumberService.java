package com.example.randomnumber.services;

import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class NumberService {
    public int between(int low, int high)
    {
        Random random = new Random();
        int number = random.nextInt(low, high+1);
        return number;
    }
}
