package com.example.randomnumber;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RandomNumberApplicationTests {

    @Test
    void contextLoads() {
    }

}
